namespace openstudio {
namespace bimserver {
/** \mainpage OpenStudio BIMserver Translator
*
*
*/
} // bimserver
} // openstudio
